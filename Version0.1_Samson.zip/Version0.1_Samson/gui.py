from tkinter import Tk, Label, Button, Entry, W , E, Scale, HORIZONTAL, Checkbutton, Radiobutton, StringVar, OptionMenu, Text, END
from lib.sitepackages import pypyodbc

class MyFirstGUI:
    
    def __init__(self, master):
        self.master = master
        master.title("A simple GUI")

        self.label1 = Label(master, text="Enter Name")
        self.label1.pack()

        self.entryName = Entry()
        self.entryName.pack()

        self.scaleAge = Scale(master, from_=0, to=120, orient=HORIZONTAL)
        self.scaleAge.pack()

        self.student = StringVar(value="1")
        self.studentBtn = Checkbutton(master,text="Are you a ITB Student?", variable=self.student, onvalue="Yes" , offvalue="No").pack()

        self.variable = StringVar(master)
        self.variable.set("Undergraduate")

        self.options = OptionMenu(master, self.variable, "Undergraduate", "First Year", "Master")
        self.options.pack()


        self.gender  =  StringVar(value="1")

        self.maleBtn = Radiobutton(root, text="Male", variable=self.gender,value="Male").pack()

        self.femaleBtn = Radiobutton(root, text="Female", variable=self.gender, value="Female").pack()

        self.txt =  Text(root, width="30", height="10")
        self.txt.pack()
        
        self.quitButton = Button(master, text="QUIT", fg="red",command=lambda: self.master.destroy()).pack()
        self.adToDatabase = Button(master, text="Add to Database", fg="red",command=self.showDB).pack()
        self.displayDatabase = Button(master, text="Display out of Database", fg="red",command=self.addToDB).pack()


    def addToDB(self):
        self.txt.delete(1.0,END)
        DBfile = '.\\samsonDatabase.mdb'
        conn = pypyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb)};DBQ='+DBfile)
        myCursor = conn.cursor()
        SQL_insert = "insert into student(uname,gender) values ('"+self.entryName.get()+"','"+self.gender.get()+"')"
        myCursor.execute(SQL_insert)
        myCursor.commit()
        self.txt.insert(END,"Saved to Database")
        self.txt.insert(END,"\n")
    
    def showDB(self):
        self.txt.delete(1.0,END)
        DBfile = '.\\samsonDatabase.mdb'
        conn = pypyodbc.connect(r'Driver={Microsoft Access Driver (*.mdb)};DBQ='+DBfile)
        myCursor = conn.cursor()
        SQL = "SELECT * FROM student"
        students = myCursor.execute(SQL)
        self.txt.insert(END,"Students from ITB: ")
        for student in students:
             self.txt.insert(END,'Name: '+ student[0] +" is gender: " + student[1])

    
       
  

root = Tk()
my_gui = MyFirstGUI(root)
root.mainloop()
