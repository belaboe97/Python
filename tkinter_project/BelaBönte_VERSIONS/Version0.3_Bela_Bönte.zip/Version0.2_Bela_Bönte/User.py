class User():
    def __init__(self,username,gender,email,password):
        self.__username=username
        self.__gender=gender
        self.__email=email
        self.__password=password

    def getUserName(self):
        return self.__username

    def getGender(self):
        return self.__gender

    def getEmail(self):
        return self.__email

    def getPassword(self):
        return self.__password


    def __str__(self):
        return self.__username + " with email: " + self.__email
